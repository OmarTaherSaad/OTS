<nav class="navbar navbar-expand-md navbar-dark bg-dark fixed-top py-0">
    <a class="navbar-brand" href="<?php echo e(route('home')); ?>">
        <img src="<?php echo e(asset('storage/assets/logo.jpg')); ?>" alt="OTS Logo" class="rounded img-fluid" />
    </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar" aria-controls="navbar"
        aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbar">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->route()->named('home') ? 'active' : ''); ?>" href="<?php echo e(route('home')); ?>">
                    
                    <i class="fas fa-user-circle"></i> <span class="text"><?php echo app('translator')->get('Home'); ?></span>
                </a>
            </li>
            
            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->route()->named('media') ? 'active' : ''); ?>" href="<?php echo e(route('media')); ?>">
                    <i class="fas fa-video"></i> <span class="text"><?php echo app('translator')->get('Media & Interviews'); ?></span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo e(request()->route()->named('youtube') ? 'active' : ''); ?>" target="_blank" ref="noreferrer"
                    href="<?php echo e(config('ots.social-media.youtube')); ?>" rel="noreferrer">
                    <i class="fab fa-youtube"></i> <span class="text"><?php echo app('translator')->get('YouTube'); ?></span>
                </a>
            </li>
        </ul>
        <div class="mx-md-auto"></div>
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link btn btn-primary text-light my-2 my-sm-0 <?php echo e(request()->route()->named('contact') ? 'active' : ''); ?>"
                    href="<?php echo e(route('contact')); ?>">
                    <i class="fas fa-envelope"></i> &NonBreakingSpace; <?php echo app('translator')->get('Contact Me'); ?>
                </a>
            </li>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown"
                    aria-haspopup="true" aria-expanded="false">
                    <i class="fas fa-globe-africa last"></i> &NonBreakingSpace; <?php echo app('translator')->get("Language"); ?>
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                    <a class="dropdown-item" href="<?php echo e(route('languageChange',['locale' => 'en'])); ?>">English</a>
                    <a class="dropdown-item" href="<?php echo e(route('languageChange',['locale' => 'ar'])); ?>">عربي</a>
                </div>
            </li>
        </ul>
    </div>
</nav><?php /**PATH C:\xampp\htdocs\OTS\resources\views/partials/navbar.blade.php ENDPATH**/ ?>