<?php $__env->startSection('title',__('Physics Classes Slots')); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <?php if($Slots->count() == 0): ?>
            <h2><?php echo app('translator')->get("I'm sorry, but no slots available for now!"); ?></h2>
            <?php endif; ?>
            <?php $__currentLoopData = $Slots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Slot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-12 col-md-4 my-1">
                <div class="card-deck">
                    <div class="card border-secondary">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($Slots->date); ?> -> <?php echo e($Slots->time); ?></h5>
                            <div class="row justify-content-center">
                                <div class="col-12">
                                    <a href="/projects/<?php echo e($Project->id); ?>/<?php echo e(str_slug($Project->name)); ?>"
                                        class="btn btn-secondary btn-block"><?php echo e(__('admin.Open')); ?></a>
                                    <?php if(auth()->guard()->check()): ?>
                                    <a href="/admin/projects/<?php echo e($Project->id); ?>/edit"
                                        class="btn btn-warning btn-block"><?php echo e(__('admin.Edit')); ?></a>
                                    <form method='POST' action='/admin/projects/<?php echo e($Project->id); ?>' class="btn-block">
                                        <?php echo method_field('DELETE'); ?>
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-danger btn-block"><?php echo e(__('admin.Delete')); ?></button>
                                    </form>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\OTS\resources\views/physics-classes/index.blade.php ENDPATH**/ ?>