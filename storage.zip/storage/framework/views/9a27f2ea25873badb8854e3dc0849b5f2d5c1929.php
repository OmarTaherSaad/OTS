<?php $__env->startSection('title',__('About Me')); ?>
<?php $__env->startSection('head'); ?>
<link rel="stylesheet" href="<?php echo e(mix('css/about.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts-First'); ?>
<script src="<?php echo e(mix('js/about.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="row justify-content-center parallax position-relative pb-md-5 pb-2">
        <div class="overlay progressive replace"></div>
        <div class="col-8 col-sm-6 col-md-3">
            <prog-img src="<?php echo e(asset('storage/photos/photo1.jpg')); ?>" alt="Omar Taher's photo"
                vclass="rounded-circle img-fluid"></prog-img>
        </div>
        <div class="col" v-view="titlesShown">
            <?php echo app('translator')->get('main.aboutMeHeader'); ?>
            <ul class="list-group titles <?php echo e(App::isLocale('ar') ? 'rtl' : ''); ?>"
                v-bind:class="{'sidenav': titleOnSide}" ref="titles" v-scroll-spy-active
                v-scroll-spy-link="{selector: 'li'}">
                <li href="#webDeveloper" class="list-group-item" v-bind:class="{'h4': !titleOnSide}">
                    <span v-if="titleOnSide"><?php echo e(__('Web Developer')); ?></span>
                    <span v-else><?php echo e(__('Full Stack Web Developer')); ?></span>
                </li>
                <li href="#cSharpDeveloper" class="list-group-item" v-bind:class="{'h4': !titleOnSide}">
                    <?php echo app('translator')->get("C# Developer"); ?>
                </li>
                <li href="#videoEditor" class="list-group-item" v-bind:class="{'h4': !titleOnSide}">
                    <?php echo app('translator')->get("Video Editor"); ?>
                </li>
                <li href="#CSEstudent" class="list-group-item" v-bind:class="{'h4': !titleOnSide}">
                    <span v-if="titleOnSide"><?php echo e(__('CSE Student')); ?></span>
                    <span v-else><?php echo e(__('Computer & Systems Engineering Student')); ?></span>
                </li>
                <li href="#youTuber" class="list-group-item" v-bind:class="{'h4': !titleOnSide}">
                    <span v-if="titleOnSide"><?php echo app('translator')->get('YouTuber'); ?></span>
                    <span v-else>
                        <?php echo app('translator')->get('main.youtuberLong'); ?>
                    </span>
                </li>
            </ul>
        </div>
    </div>
</div>

<div class="container-fluid" v-scroll-spy="{offset: 150, allowNoActive: true}">
    
    <div id="webDeveloper" class="row parallax bg-primary pt-4 px-md-0 px-3">
        <h1 class="text-light px-4"><?php echo app('translator')->get("Full Stack Web Developer"); ?></h1>
        <div class="col-12 text-center text-light">
            <h3 class="text-dark bg-light rounded p-3 mx-auto" style="width: fit-content"><?php echo app('translator')->get("Technologies I use in Web Development"); ?></h3>
            <div class="row justify-content-center">
                <div v-for="item in skills.web" class="col-4 col-md-2">
                    <prog-img :src="item.img" :alt="item.title" vclass="m-2 rounded img-fluid skill">
                    </prog-img>
                    <h4>{{ item.title }}</h4>
                </div>
            </div>
        </div>
        
        <div class="col-12 text-center text-light py-3">
            <h3><?php echo app('translator')->get("Previous Work"); ?></h3>
            <div class="row justify-content-center">
                <div v-for="item in work.web" class="col-12 col-md-4 my-md-0 my-1">
                    <div class="card">
                        <prog-img class="card-img" :src="item.img" :alt="item.titleEN"></prog-img>
                        <div class="card-img-overlay" @click="openLink(item.href)">
                            <div class="workOverlay"></div>
                            <?php if(App::isLocale('ar')): ?>
                            <h5 class="card-title">{{ item.titleAR }}</h5>
                            <?php else: ?>
                            <h5 class="card-title">{{ item.titleEN }}</h5>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="row parallax position-relative">
        <div class="overlay progressive replace"></div>
        <div class="col">
            <section id="cSharpDeveloper" class="pt-4">
                <h1 class="px-4"><?php echo app('translator')->get("C# Developer"); ?></h1>
                <div class="row">
                    <div class="col-12 text-center text-dark">
                        <h3 class="text-light bg-dark rounded p-3 mx-auto" style="width: fit-content"><?php echo app('translator')->get("Technologies & Frameworks I use in C# Development"); ?></h3>
                        <div class="row justify-content-around">
                            <div v-for="item in skills.csharp" class="col-4 col-md-2">
                                <prog-img :src="item.img" :alt="item.title" vclass="m-2 rounded img-fluid skill dark">
                                </prog-img>
                                <h4 v-html="item.title"></h4>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-12 text-center text-dark py-3">
                        <h3><?php echo app('translator')->get('Previous Work'); ?></h3>
                        <div class="row justify-content-center">
                            <div v-for="item in work.csharp" class="col-12 col-md-4 my-md-0 my-1">
                                <div class="card text-light">
                                    <prog-img class="card-img" :src="item.img" :alt="item.title"></prog-img>
                                    <div class="card-img-overlay no-pointer"
                                        >
                                        <div class="workOverlay"></div>
                                        <h5 class="card-title">{{ item.title }}</h5>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
    
    <div id="videoEditor" class="row parallax bg-light text-dark pt-4 px-md-0 px-3">
        <h1 class="px-4"><?php echo app('translator')->get('Video Editor'); ?></h1>
        <div class="col-12 text-center">
            <h3 class="text-light bg-dark rounded p-3 mx-auto" style="width: fit-content"><?php echo app('translator')->get('What I do in Video Editing'); ?></h3>
            <div class="row justify-content-center">
                <div v-for="item in skills.videoEditing" class="col-6 col-md-3">
                    <prog-img :src="item.img" :alt="item.titleEN" vclass="m-2 rounded img-fluid skill dark">
                    </prog-img>
                    <?php if(App::isLocale('ar')): ?>
                    <h4>{{ item.titleAR }}</h4>
                    <p v-html="item.descAR"></p>
                    <?php else: ?>
                    <h4>{{ item.titleEN }}</h4>
                    <p v-html="item.descEN"></p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    
    <div class="row parallax position-relative">
        <div class="overlay progressive replace"></div>
        <div class="col">
            <section id="CSEstudent" class="pt-4">
                <h1 class="px-4"><?php echo app('translator')->get('Computer & Systems Engineering Student'); ?></h1>
                <div class="row justify-content-center">
                    <div class="col-10 col-md-6 my-2">
                        <h4>
                            <i class="fas fa-map-marked-alt fa-lg"></i>
                            <a href="https://goo.gl/maps/gwRRR8g3QXTYmkS57" target="_blank" rel="noreferrer" aria-label="Faculty of Engineering, Ain Shams University">
                                <?php echo app('translator')->get('Faculty of Engineering, Ain Shams University'); ?>
                            </a>
                        </h4>
                    </div>
                    <div class="col-10 col-md-6 my-2">
                        <h4><i class="fas fa-graduation-cap fa-lg">
                            </i> <?php echo app('translator')->get('To be graduated in 2020'); ?>
                        </h4>
                    </div>
                </div>
                <div class="row justify-content-center">
                    <div class="col-12 text-center text-dark">
                        <h3 class="text-light bg-dark rounded p-3 mx-auto" style="width: fit-content">
                            <?php echo app('translator')->get('Some of Courses I have completed'); ?>
                        </h3>
                        <div class="row justify-content-center">
                            <div v-for="item in skills.cse" class="col-6 col-md-2">
                                <prog-img :src="item.img" :alt="item.title" vclass="m-2 rounded img-fluid skill dark">
                                </prog-img>
                                <h5 v-html="item.title"></h5>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-md-6 text-center">
                        <h4 class="font-weight-bold">
                            <?php echo app('translator')->get('And many others, of course.'); ?>
                        </h4>
                    </div>
                </div>
            </section>
        </div>
    </div>
    
     <div id="youTuber" class="row parallax bg-primary pt-4 px-md-0 px-3 justify-content-center">
        <h1 class="text-light px-4"><?php echo app('translator')->get('YouTuber'); ?></h1>
        <div class="col-12 text-center text-light">
            <h3 class="text-dark bg-light rounded p-3 mx-auto" style="width: fit-content"><?php echo app('translator')->get('My YouTube Channel in 20 seconds'); ?></h3>
        </div>
        <div class="col-10 col-md-8">
            <h5 class="loadingIframe"></h5>
            <div class="embed-responsive embed-responsive-16by9 iframeProgressive" hidden></div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script defer>
    //Animate "loadingIframe" text
    i = 0;
    <?php if(App::isLocale('ar')): ?>
    text = "جاري إحضار الفيديو";
    <?php else: ?>
    text = "Getting video";
    <?php endif; ?>
    var interval = setInterval(function() {
    $(".loadingIframe").html(text+Array((++i % 4)+1).join("."));
    if (i===10)
        <?php if(App::isLocale('ar')): ?>
        text = "جاري إحضار الفيديو";
        <?php else: ?>
        text = "Getting video";
        <?php endif; ?>
    }, 500);

    $('.iframeProgressive').each(function(i,element) {
        var iframe = document.createElement('iframe');
        iframe.onload = function() {
            clearInterval(interval);
            $(element).siblings('.loadingIframe').remove();
            element.removeAttribute('hidden');
        };
        $(iframe).attr({
            frameborder: 0,
            allow: "accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture",
            allowfullscreen: true,
            class: "embed-responsive-item",
            title: "Introductory video for Omar Taher's youtube channel"
        })
        iframe.src = "https://www.youtube.com/embed/nOWOaLBYkJI";
        element.appendChild(iframe);
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\OTS\resources\views/about.blade.php ENDPATH**/ ?>