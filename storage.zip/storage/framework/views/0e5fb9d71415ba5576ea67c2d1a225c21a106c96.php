<?php $__env->startSection('title',__("Physics Tutorials Reservation")); ?>
<?php $__env->startSection('head'); ?>
<link rel="stylesheet" href="<?php echo e(mix('css/forms.css')); ?>">
<?php $__env->stopSection(); ?>

<?php
    $chaptersStr = '[';
    foreach ($chapters as $key => $chapter) {
        $chapter->key = $key;
        $chaptersStr .= collect($chapter,$key)->toJson() . ',';
    }
    $chaptersStr = rtrim($chaptersStr, ',') . ']';
?>
<?php $__env->startSection('scripts-First'); ?>
<script>
    window.AllChapters = <?php echo $chaptersStr; ?>;
    window.locale = '<?php echo e(App::getLocale()); ?>';
</script>
<script src="<?php echo e(mix('js/physicsClasses.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row my-1">
        <div class="col-12 col-md-auto">
            <h2><?php echo app('translator')->get('Add New Slot for Physics Classes'); ?></h2>
        </div>
    </div>
    <div class="row justify-content-center mt-2">
        <div class="col-12 col-md-6 text-<?php echo e(App::isLocale('ar') ? 'right' : 'left'); ?>">
            <form action="<?php echo e(route('physics.store')); ?>" method="POST" v-on:submit.prevent="validate($event)">
                <div class="alert alert-danger" role="alert" v-if="error">
                    <?php echo app('translator')->get("Please, fill all the data."); ?>
                </div>
                <?php echo csrf_field(); ?>
                <div class="form-group mb-1" :class="{'focused': date != null}" dir="ltr">
                    <label for="date"><?php echo app('translator')->get('Select Range of dates that suits you'); ?></label>
                    <Date-Time-Picker
                        v-model="date"
                        formatted="DD-MM-YYYY"
                        output-format="DD-MM-YYYY"
                        :only-date="true"
                        min-date="<?php echo e(\Carbon\Carbon::now()->toDateString()); ?>"
                        :range="true"
                        :right="true"
                        dark
                        ref="date"
                        input-size="sm">
                        <input type="text" v-bind:value="dateFormatted" class="form-control" :class="{'filled': date != null}" name="date" id="date" readonly>
                    </Date-Time-Picker>
                </div>

                <div class="form-group" :class="{'focused': start_time != null}">
                    <label for="start_time"><?php echo app('translator')->get('Perferred Class Start Time'); ?></label>
                    <Date-Time-Picker
                        v-model="start_time"
                        formatted="h:mm A"
                        format="h:mm A"
                        :only-time="true"
                        :minute-interval="30"
                        input-size="sm"
                        dark
                        ref="start_time">
                        <input type="text" v-bind:value="start_time" class="form-control" :class="{'filled': start_time != null}" name="start_time" id="start_time" readonly>
                    </Date-Time-Picker>
                </div>

                <div class="form-group" :class="{'focused': end_time != null}">
                    <label for="end_time"><?php echo app('translator')->get('Perferred Class End Time'); ?></label>
                    <Date-Time-Picker
                        v-model="end_time"
                        formatted="h:mm A"
                        format="h:mm A"
                        :only-time="true"
                        :minute-interval="30"
                        input-size="sm"
                        dark
                        ref="end_time">
                        <input type="text" v-bind:value="end_time" class="form-control" :class="{'filled': end_time != null}" name="end_time" id="end_time" readonly>
                    </Date-Time-Picker>
                </div>

                

                
                <div>
                    <div class="form-group mb-0">
                        <multiselect
                            v-model="chapters"
                            :options="AllChapters"
                            :label="chapterNames"
                            track-by="key"
                            :close-on-select="false"
                            :multiple="true"
                            select-label="<?php echo app('translator')->get('Press enter to select'); ?>"
                            selected-label="<?php echo app('translator')->get('Selected'); ?>"
                            deselect-label="<?php echo app('translator')->get('Press enter to remove'); ?>"
                            placeholder="<?php echo app('translator')->get('Select chapters you need help with'); ?>">
                        <template slot="noResult">
                            <?php echo app('translator')->get("Nothing matches your search :/"); ?>
                        </template>
                        </multiselect>
                    </div>
                    <div class="form-check">
                        <label class="form-check-label">
                            <input type="checkbox" name="changeLang" v-model="changeLang">
                            <?php echo app('translator')->get("Chapters names in Arabic"); ?>
                        </label>
                    </div>

                    <div class="form-group">
                        <label for="type"><?php echo app('translator')->get('What kind of help do you need?'); ?></label>
                        <select id="type" class="custom-select" name="type" v-model="HelpType" required>
                            <option disabled selected value="null"></option>
                            <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($key); ?>"><?php echo app('translator')->get($type->en); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group focused">
                        <label for="fees"><?php echo app('translator')->get("Suitable Fees for you"); ?></label>
                        <input id="fees" class="form-control filled" type="number" name="fees" v-model="fees" required>
                        <small class="form-text text-muted"><?php echo app('translator')->get("If you cannot pay for it, just type 0, it's okay."); ?></small>
                    </div>

                    <div class="form-group">
                        <label for="name"><?php echo app('translator')->get("Name"); ?></label>
                        <input id="name" class="form-control" type="text" name="name" v-model="name" required>
                    </div>

                    <div class="form-group">
                        <label for="mobile_no"><?php echo app('translator')->get("Mobile Number"); ?></label>
                        <input id="mobile_no" class="form-control" type="number" name="mobile_no" v-model="mobile_no" pattern="[0-9]{11}" required>
                    </div>

                    

                    <div class="form-group">
                        <label for="place"><?php echo app('translator')->get('Select your preferred type for class place'); ?></label>
                        <select id="place" class="custom-select" name="place" v-model="place" required>
                            <option disabled selected value="null"></option>
                            <?php $__currentLoopData = $places; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($key); ?>"><?php echo app('translator')->get($item->en); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    

                    <div class="form-group">
                        <label for="content"><?php echo app('translator')->get("Any Additional Information / requests"); ?></label>
                        <textarea id="content" class="form-control" name="content" v-model="content" rows="3"></textarea>
                    </div>


                </div>
                
                <div class="form-group">
                    <input type="submit" class="btn btn-primary" value="<?php echo app('translator')->get('Submit'); ?>" />
                </div>
            </form>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script defer src="https://www.google.com/recaptcha/api.js?render=6Lc447UUAAAAAKUbWbf6jTvZRmxvSOxnKW-VhneB"></script>
<script type="text/javascript" src="<?php echo e(mix('js/forms.js')); ?>" defer></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\OTS\resources\views/physics-classes/create.blade.php ENDPATH**/ ?>