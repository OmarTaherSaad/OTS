<div class="splash_screen">
    <div class="loader">
        <div class="loader__bar"></div>
        <div class="loader__bar"></div>
        <div class="loader__bar"></div>
        <div class="loader__bar"></div>
        <div class="loader__bar"></div>
        <div class="loader__ball"></div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\OTS\resources\views/partials/splash-screen.blade.php ENDPATH**/ ?>