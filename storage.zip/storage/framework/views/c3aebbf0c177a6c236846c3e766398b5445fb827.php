<?php $__env->startSection('title',__("Contact Me")); ?>
<?php $__env->startSection('head'); ?>
<link rel="stylesheet" href="<?php echo e(mix('css/forms.css')); ?>">
<?php if(App::isLocale('ar')): ?>
<style>
    label:not(.form-check-label) {
        right: 5px;
    }
</style>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid <?php echo e(App::isLocale('ar') ? 'text-right' : 'text-left'); ?>">
    <div class="row">
        <div class="col-12">
            <div class="jumbotron mt-lg-3 mt-5">
                <h1 class="display-4"><?php echo e(__("I'll be glad to recieve your message")); ?></h1>
                <p class="lead"><?php echo e(__("It's hard to answer immediately, but I will do as fast as possible")); ?></p>
            </div>
        </div>
    </div>
    <div class="row justify-content-center">
        <!--Contact Form START-->
        <div class="col-12 col-xl-8">
            <form action="<?php echo e(route('contact-submit')); ?>" method="POST" id="ContactForm">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-12 my-2">
                        <div class="form-group my-1 <?php echo e(old('name') ? 'focused' : ''); ?>">
                            <label for="name"><?php echo e(__("Name")); ?></label>
                            <input class="form-control <?php echo e($errors->has('name') ? 'is-danger filled invalid' : (old('name') ? 'filled valid' : '')); ?>" type="text"
                                name="name" value="<?php echo e(old('name')); ?>" required>
                        </div>
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="col-xl-6 col-12 my-2">
                        <div class="form-group my-1 <?php echo e(old('phone') ? 'focused' : ''); ?>">
                            <label for="phone"><?php echo e(__("Mobile Number")); ?></label>
                            <input class="form-control <?php echo e($errors->has('phone') ? 'is-danger filled invalid' : (old('phone') ? 'filled valid' : '')); ?>" type="tel"
                                name="phone" value="<?php echo e(old('phone')); ?>" required pattern="[0-9]{5,}">
                        </div>
                        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="col-xl-6 col-12 my-2">
                        <div class="form-group my-1 <?php echo e(old('email') ? 'focused' : ''); ?>">
                            <label for="email"><?php echo e(__("Email Address")); ?></label>
                            <input class="form-control <?php echo e($errors->has('email') ? 'is-danger filled invalid' : (old('email') ? 'filled valid' : '')); ?>" type="email"
                                name="email" value="<?php echo e(old('email')); ?>" required>
                        </div>
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="col-12 my-2">
                        <div class="form-group my-1 <?php echo e(old('subject') ? 'focused' : ''); ?>">
                            <label for="subject"><?php echo e(__("What are you sending me about?")); ?></label>
                            <input class="form-control <?php echo e($errors->has('subject') ? 'is-danger filled invalid' : (old('subject') ? 'filled valid' : '')); ?>" type="text"
                                name="subject" value="<?php echo e(old('subject')); ?>" required>
                        </div>
                        <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                    <div class="col-12 my-2 justify-content-center">
                        <div class="form-group my-1 <?php echo e(old('message') ? 'focused' : ''); ?>">
                            <label for="message"><?php echo app('translator')->get("Message"); ?></label>
                            <textarea class="form-control <?php echo e($errors->has('message') ? 'is-danger filled invalid' : (old('message') ? 'filled valid' : '')); ?>" name="message"
                                rows="4" required><?php echo e(old('message')); ?></textarea>
                        </div>
                        <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="col-12 justify-content-center">
                        <input class="btn btn-primary" type="submit" value="<?php echo app('translator')->get("Send"); ?>">
                    </div>
                </div>
            </form>

        </div>
        <!--Contact Form END-->
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script defer src="https://www.google.com/recaptcha/api.js?render=6Lc447UUAAAAAKUbWbf6jTvZRmxvSOxnKW-VhneB"></script>
<script type="text/javascript" src="<?php echo e(mix('js/forms.js')); ?>" defer></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\OTS\resources\views/contact.blade.php ENDPATH**/ ?>