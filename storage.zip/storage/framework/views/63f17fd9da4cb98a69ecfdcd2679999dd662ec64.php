<?php if($message = Session::get('success')): ?>

<div class="alert alert-success alert-dismissible fade show <?php echo e(App::getLocale() == 'ar' ? 'text-right' : ''); ?>" role="alert">

	<button type="button" class="close" data-dismiss="alert">×</button>	

		<strong><?php echo e($message); ?></strong>

</div>

<?php endif; ?>



<?php if($errors->any()): ?>
<div class="alert alert-danger alert-dismissible fade show <?php echo e(App::getLocale() == 'ar' ? 'text-right' : ''); ?>" role="alert">

		<button type="button" class="close" data-dismiss="alert">×</button>	
		<strong>
			<ul>
				<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<li><?php echo e($error); ?></li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</ul>
		</strong>
	
	</div>
<?php endif; ?>

<?php if($message = Session::get('error')): ?>

<div class="alert alert-danger alert-dismissible fade show <?php echo e(App::getLocale() == 'ar' ? 'text-right' : ''); ?>" role="alert">

	<button type="button" class="close" data-dismiss="alert">×</button>	

		<strong><?php echo e($message); ?></strong>

</div>

<?php endif; ?>



<?php if($message = Session::get('warning')): ?>

<div class="alert alert-warning alert-dismissible fade show <?php echo e(App::getLocale() == 'ar' ? 'text-right' : ''); ?>" role="alert">

	<button type="button" class="close" data-dismiss="alert">×</button>	

	<strong><?php echo e($message); ?></strong>

</div>

<?php endif; ?>



<?php if($message = Session::get('info')): ?>

<div class="alert alert-info alert-dismissible fade show <?php echo e(App::getLocale() == 'ar' ? 'text-right' : ''); ?>" role="alert">

	<button type="button" class="close" data-dismiss="alert">×</button>	

	<strong><?php echo e($message); ?></strong>

</div>

<?php endif; ?><?php /**PATH C:\xampp\htdocs\OTS\resources\views/partials/show-alerts.blade.php ENDPATH**/ ?>