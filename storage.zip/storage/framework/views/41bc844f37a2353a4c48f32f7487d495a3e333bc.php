<?php $__env->startSection('title',__("Physics Tutorials Reservation")); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row my-1">
        <div class="col-12 col-md-auto">
            <h2><?php echo app('translator')->get('Register for Physics Classes'); ?></h2>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="w-auto h-100">
                <iframe src="https://docs.google.com/forms/d/e/1FAIpQLSd2lMr9oqLBOZ03szQlWsEIcRLifa3-3VVHWjXCQ2AbBfluyQ/viewform?embedded=true" frameborder="0" style="width:100%; height: 65vh">Loading…</iframe>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\OTS\resources\views/physics-classes/register.blade.php ENDPATH**/ ?>