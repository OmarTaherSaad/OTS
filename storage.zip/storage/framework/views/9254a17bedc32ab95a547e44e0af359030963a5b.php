<footer class="footer text-center bg-dark text-light">
    <div class="container">
        <div class="row justify-content-center align-items-center py-1">
            <div class="col-12">
                <h6 class="font-weight-bold"><?php echo e(__('main.copyrights')); ?></h6>
            </div>
            <div class="col-12">
                <h6 class="text-monospace mb-0">
                    <?php if(App::getLocale() == 'ar'): ?>
                    تم تطوير الموقع بواسطة <a href="mailto:omar@otscommunity.com" class="text-light font-weight-bold">OTS</a>
                    <?php else: ?>
                    Developed by <a href="mailto:omar@otscommunity.com" class="text-light font-weight-bold">OTS</a>
                    <?php endif; ?>
                </h6>
            </div>
        </div>
    </div>
</footer><?php /**PATH C:\xampp\htdocs\OTS\resources\views/partials/footer.blade.php ENDPATH**/ ?>