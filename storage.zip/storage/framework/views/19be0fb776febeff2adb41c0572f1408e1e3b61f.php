<?php $__env->startSection('title',_("Media & Interviews")); ?>

<?php $__env->startSection('head'); ?>
<style>
    .card-header button {
        font-size: 1.3em;
        color: #d24536;
    }

    .card-header button:hover {
        text-decoration: none;
        color: #6d65ae;
    }

    .card-header button:focus {
        text-decoration: none;
    }
    .thumbnail {
        border-radius: 20px;
        min-width: 20vh;
        min-height: 20vh;
        border-radius: 20px;
        height: 100%;
        width: 100%;
        transition: 0.5s ease;
        background-color: rgba(255, 255, 255, 1);
    }

    .thumbnail:hover {
        background-color: rgba(210, 69, 54, 1);
        cursor: pointer;
    }

    .thumbnail:hover .thumbnail-text {
        font-size: 150%;
        color: black;
        font-weight: bolder;
    }

    .thumbnail-text {
        position: absolute;
        top: 50%;
        left: 50%;
        width: inherit;
        transform: translate(-50%, -50%);
        -o-transform: translate(-50%, -50%);
        -ms-transform: translate(-50%, -50%);
        -moz-transform: translate(-50%, -50%);
        -webkit-transform: translate(-50%, -50%);
        text-align: center;
        font-size: 130%;
        font-weight: bold;
        color: #d24536;
        transition: 0.4s ease;
    }

    .thumbnail-text:hover {
        text-decoration: none;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-3">
    <div class="row justify-content-center mt-5">
        <div class="col-12 text-center">
            <h2><?php echo e(__("My Interviews in TV & Other Media")); ?></h2>
            <hr>
        </div>
    </div>
    <div class="row justify-content-center">
        <div class="col-12 col-md-10 m-md-2 m-1 text-center">
            <h3><?php echo app('translator')->get("TV & Videos"); ?></h3>
            <div class="accordion" id="TV">
                <?php $__currentLoopData = $Items->where('typeCode','tv'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card">
                    <div class="card-header" id="TVheading<?php echo e($loop->index); ?>">
                        <h5 class="mb-0">
                            <button class="btn btn-link collapsed" type="button" data-toggle="collapse"
                                data-target="#TVcollapse<?php echo e($loop->index); ?>" aria-expanded="false"
                                aria-controls="collapse<?php echo e($loop->index); ?>">
                                <?php if(App::isLocale('ar')): ?>
                                <?php echo e($item->nameAR); ?>

                                <?php else: ?>
                                <?php echo e($item->nameEN); ?>

                                <?php endif; ?>
                            </button>
                        </h5>
                    </div>

                    <div id="TVcollapse<?php echo e($loop->index); ?>" class="collapse"
                        aria-labelledby="TVheading<?php echo e($loop->index); ?>" data-parent="#TV" i-src="<?php echo e($item->link); ?>"
                        index="<?php echo e($loop->index); ?>">
                        <div class="card-body">
                            <div class="i-loader">
                                <h5 class="loading"></h5>
                                <div class="lds-ellipsis">
                                    <div></div>
                                    <div></div>
                                    <div></div>
                                    <div></div>
                                </div>
                            </div>
                            <div class="embed-responsive embed-responsive-16by9 p-3" id="TV<?php echo e($loop->index); ?>" hidden>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <div class="col-12 text-center">
            <hr>
            <h3><?php echo app('translator')->get("Paper & Digital Newspapers"); ?></h3>
        </div>
        <?php $__currentLoopData = $Items->where('typeCode','written'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-5 col-md-2 m-md-2 m-1 thumbnail text-center overlay">
            <a href="<?php echo e($item->link); ?>" class="thumbnail-text" target="_blank" rel="noreferrer">
                <?php if(App::isLocale('ar')): ?>
                <?php echo e($item->nameAR); ?>

                <?php else: ?>
                <?php echo e($item->nameEN); ?>

                <?php endif; ?>
            </a>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script defer>
    //Animate "loading" text
    i = 0;
    <?php if(App::isLocale('ar')): ?>
    text = "جاري إحضار الفيديو";
    <?php else: ?>
    text = "Getting video";
    <?php endif; ?>
    var interval = setInterval(function() {
    $(".loading").html(text+Array((++i % 4)+1).join("."));
    if (i===10)
        <?php if(App::isLocale('ar')): ?>
        text = "جاري إحضار الفيديو";
        <?php else: ?>
        text = "Getting video";
        <?php endif; ?>
        //If all iframes loaded, stop the interval
        if ($(".loading").length < 1) {
            clearInterval(interval);
        }
    }, 500);

    $("#TV").on('show.bs.collapse',function(e) {
        const el = $(e.target);
        if (el.has('iframe').length) {
            return;
        }
        var iframe = document.createElement('iframe');
        iframe.onload = function() {
            el.find('.i-loader').remove();
            document.getElementById('TV'+el.attr('index')).removeAttribute('hidden');
        };
        iframe.src = $(e.target).attr('i-src');
        document.getElementById('TV'+$(e.target).attr('index')).appendChild(iframe);
    });
    //Thumbnail clicks the link inside it
    $(".thumbnail").click(function() {
        window.open($(this).find('a').attr('href'),'_blank');
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\OTS\resources\views/media.blade.php ENDPATH**/ ?>